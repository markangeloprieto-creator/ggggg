import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:google_fonts/google_fonts.dart';
import 'speech_stub.dart'
    if (dart.library.html) 'speech_web.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool _isDarkMode = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'I-TYPEKOTO — Web TTS + STT',
      theme: ThemeData(
        brightness: _isDarkMode ? Brightness.dark : Brightness.light,
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
        scaffoldBackgroundColor:
            _isDarkMode ? Colors.black : Colors.white,
        textTheme: GoogleFonts.poppinsTextTheme(
          _isDarkMode
              ? ThemeData.dark().textTheme
              : ThemeData.light().textTheme,
        ),
      ),
      home: TtsHomePage(
        toggleTheme: () => setState(() => _isDarkMode = !_isDarkMode),
        isDarkMode: _isDarkMode,
      ),
    );
  }
}

class TtsHomePage extends StatefulWidget {
  final VoidCallback toggleTheme;
  final bool isDarkMode;
  const TtsHomePage(
      {super.key, required this.toggleTheme, required this.isDarkMode});

  @override
  State<TtsHomePage> createState() => _TtsHomePageState();
}

class _TtsHomePageState extends State<TtsHomePage> {
  final FlutterTts _tts = FlutterTts();
  final TextEditingController _controller = TextEditingController(
    text: 'Welcome to I-TYPEKOTO. Type text here and press Speak!',
  );

  List<String> _languages = [];
  String? _selectedLanguage;
  double _rate = 0.9;
  double _pitch = 1.0;
  bool _isSpeaking = false;
  bool _isInitializing = true;
  bool _isListening = false;
  String _liveText = "";

  double _textScale = 1.0;
  final List<String> _history = [];

  late WebSpeechApi _speechApi;
  final Map<int, String> _finalSegments = {};
  final Map<int, String> _interimSegments = {};
  bool _isProgrammaticUpdate = false;
  String _lastAppendedFinal = "";
  final Set<String> _recentFinals = {};

  @override
  void initState() {
    super.initState();
    _initTts();
    _speechApi = WebSpeechApi();

    _controller.addListener(() {
      if (_isProgrammaticUpdate) return;
      if (_controller.text.trim().isEmpty) {
        setState(() {
          _finalSegments.clear();
          _interimSegments.clear();
          _liveText = "";
          _lastAppendedFinal = "";
          _recentFinals.clear();
        });
      }
    });
  }

  Future<void> _initTts() async {
    try {
      await _tts.setSpeechRate(_rate);
      await _tts.setPitch(_pitch);
      final langs = await _tts.getLanguages;
      if (langs != null) _languages = List<String>.from(langs);

      _tts.setStartHandler(() => setState(() => _isSpeaking = true));
      _tts.setCompletionHandler(() {
        setState(() => _isSpeaking = false);
      });
      _tts.setErrorHandler((msg) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("TTS error: $msg")),
        );
        setState(() => _isSpeaking = false);
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error initializing TTS: $e")),
      );
    }

    setState(() {
      _isInitializing = false;
      if (_languages.isNotEmpty) _selectedLanguage ??= _languages.first;
    });
  }

  Future<void> _speak() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    if (_selectedLanguage != null) await _tts.setLanguage(_selectedLanguage!);
    await _tts.setSpeechRate(_rate);
    await _tts.setPitch(_pitch);
    await _tts.speak(text);

    if (!_history.contains(text)) _history.insert(0, text);
  }

  Future<void> _stop() async {
    await _tts.stop();
    setState(() => _isSpeaking = false);
  }

  void _startListening() {
    if (_isListening) return;

    setState(() {
      _isListening = true;
      _liveText = "";
      _lastAppendedFinal = "";
    });

    _speechApi.start(
      (String? result, bool isFinal, int index) {
        if (result == null || result.trim().isEmpty) return;
        final trimmed = result.trim();
        setState(() {
          if (isFinal) {
            _finalSegments[index] = trimmed;
            _interimSegments.remove(index);
          } else {
            _interimSegments[index] = trimmed;
          }

          final allIndexes =
              <int>{..._finalSegments.keys, ..._interimSegments.keys}
                  .toList()
                ..sort();
          final buffer = StringBuffer();
          for (final idx in allIndexes) {
            if (_finalSegments.containsKey(idx)) {
              final seg = _finalSegments[idx]!;
              final part =
                  buffer.isEmpty ? seg : _trimOverlap(buffer.toString(), seg);
              if (part.isNotEmpty) {
                if (buffer.isNotEmpty) buffer.write(' ');
                buffer.write(part);
              }
            }
          }
          for (final idx in allIndexes) {
            if (_interimSegments.containsKey(idx) &&
                !_finalSegments.containsKey(idx)) {
              final seg = _interimSegments[idx]!;
              final part =
                  buffer.isEmpty ? seg : _trimOverlap(buffer.toString(), seg);
              if (part.isNotEmpty) {
                if (buffer.isNotEmpty) buffer.write(' ');
                buffer.write(part);
              }
            }
          }
          _liveText = buffer.toString().trim();
          _setControllerText(_liveText);
        });
      },
      onError: (error) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Speech error: $error")),
        );
        _stopListening();
      },
      onEnd: () {
        setState(() {
          _isListening = false;
          _setControllerText(_liveText);
        });
      },
    );
  }

  void _stopListening() {
    _speechApi.stop();
    setState(() => _isListening = false);
  }

  String _trimOverlap(String existing, String next) {
    final exWords = existing.trim().split(RegExp(r'\s+'));
    final nwWords = next.trim().split(RegExp(r'\s+'));
    if (exWords.isEmpty || nwWords.isEmpty) return next.trim();
    final maxCheck =
        exWords.length < nwWords.length ? exWords.length : nwWords.length;
    for (int k = maxCheck; k > 0; k--) {
      var match = true;
      for (int i = 0; i < k; i++) {
        if (exWords[exWords.length - k + i].toLowerCase() !=
            nwWords[i].toLowerCase()) {
          match = false;
          break;
        }
      }
      if (match) {
        return nwWords.sublist(k).join(' ').trim();
      }
    }
    return next.trim();
  }

  void _setControllerText(String text, {bool moveCursorToEnd = true}) {
    _isProgrammaticUpdate = true;
    _controller.text = text;
    if (moveCursorToEnd) {
      _controller.selection = TextSelection.fromPosition(
        TextPosition(offset: _controller.text.length),
      );
    }
    Future.microtask(() => _isProgrammaticUpdate = false);
  }

  Widget _buildSlider(String label, double value, double min, double max,
      ValueChanged<double> onChanged,
      {double fontSize = 14}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: fontSize,
                color: widget.isDarkMode ? Colors.white : Colors.black)),
        Slider(
          value: value,
          min: min,
          max: max,
          divisions: 10,
          label: value.toStringAsFixed(2),
          onChanged: onChanged,
        ),
      ],
    );
  }

  Widget _buildButton(
      {required String label,
      required IconData icon,
      required VoidCallback? onPressed,
      Color? color,
      double fontSize = 16}) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon, size: fontSize),
      label: Text(label, style: TextStyle(fontSize: fontSize)),
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor:
            widget.isDarkMode ? Colors.grey[900] : Colors.indigo,
        title: const Text("I-TYPEKOTO"),
        actions: [
          IconButton(
            icon: Icon(
                widget.isDarkMode ? Icons.light_mode : Icons.dark_mode),
            onPressed: widget.toggleTheme,
          ),
        ],
      ),
      body: LayoutBuilder(builder: (context, constraints) {
        double width = constraints.maxWidth;

        // Breakpoints
        bool isPhone = width < 600;
        bool isTablet = width >= 600 && width < 1024;
        bool isLaptop = width >= 1024 && width < 1440;
        bool isMonitor = width >= 1440;

        double padding = isPhone ? 8 : isTablet ? 16 : 24;
        double fontSize = isPhone ? 16 : isTablet ? 18 : 20;
        double sliderFontSize = isPhone ? 12 : 14;

        return SingleChildScrollView(
          padding: EdgeInsets.all(padding),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                controller: _controller,
                maxLines: 5,
                style: TextStyle(
                    fontSize: fontSize * _textScale,
                    color:
                        widget.isDarkMode ? Colors.white : Colors.black),
                decoration: InputDecoration(
                  labelText: "Enter text here",
                  labelStyle: TextStyle(
                      color: widget.isDarkMode
                          ? Colors.white70
                          : Colors.black54),
                  border: const OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.clear),
                    onPressed: () {
                      _controller.clear();
                    },
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                      child: _buildSlider(
                          "Text Size", _textScale, 0.8, 2.0,
                          (v) => setState(() => _textScale = v),
                          fontSize: sliderFontSize)),
                ],
              ),
              const SizedBox(height: 10),
              if (_languages.isNotEmpty)
                DropdownButtonFormField<String>(
                  decoration: InputDecoration(
                    labelText: 'Select Language',
                    labelStyle: TextStyle(
                        color: widget.isDarkMode
                            ? Colors.white70
                            : Colors.black54),
                    border: const OutlineInputBorder(),
                  ),
                  value: _selectedLanguage,
                  items: _languages
                      .map((l) =>
                          DropdownMenuItem(value: l, child: Text(l)))
                      .toList(),
                  onChanged: (v) => setState(() => _selectedLanguage = v),
                ),
              const SizedBox(height: 10),
              _buildSlider("Rate", _rate, 0.1, 1.5,
                  (v) => setState(() => _rate = v),
                  fontSize: sliderFontSize),
              _buildSlider("Pitch", _pitch, 0.5, 2.0,
                  (v) => setState(() => _pitch = v),
                  fontSize: sliderFontSize),
              const SizedBox(height: 10),
              Wrap(
                spacing: 12,
                runSpacing: 8,
                alignment: WrapAlignment.center,
                children: [
                  _buildButton(
                      label: "Speak",
                      icon: Icons.volume_up,
                      onPressed: _speak,
                      fontSize: fontSize),
                  _buildButton(
                      label: "Stop",
                      icon: Icons.stop,
                      color: Colors.red,
                      onPressed: _isSpeaking ? _stop : null,
                      fontSize: fontSize),
                  _buildButton(
                      label: "Copy",
                      icon: Icons.copy,
                      onPressed: () {
                        Clipboard.setData(
                            ClipboardData(text: _controller.text));
                        ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                                content: Text("Copied to clipboard")));
                      },
                      fontSize: fontSize),
                  _buildButton(
                      label: "Voice Input",
                      icon: Icons.mic,
                      color: Colors.green,
                      onPressed: _startListening,
                      fontSize: fontSize),
                  _buildButton(
                      label: "Stop Voice",
                      icon: Icons.mic_off,
                      color: Colors.orange,
                      onPressed: _stopListening,
                      fontSize: fontSize),
                ],
              ),
              const SizedBox(height: 10),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _history.length,
                itemBuilder: (context, index) => ListTile(
                  title: Text(_history[index],
                      style: TextStyle(
                          fontSize: fontSize,
                          color: widget.isDarkMode
                              ? Colors.white
                              : Colors.black)),
                  onTap: () => _setControllerText(_history[index]),
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}
