typedef ResultCallback = void Function(String? text, bool isFinal, int resultIndex);
typedef VoidCallback = void Function();

class WebSpeechApi {
  bool get isSupported => false;
  void initialize({ required ResultCallback onResult, VoidCallback? onEnd, Function(String)? onError }) {}
  void start(ResultCallback onResult, { Function(String)? onError, VoidCallback? onEnd, bool debug = false }) {
    onError?.call("Speech recognition not supported on this platform.");
  }
  void stop() {}
}
