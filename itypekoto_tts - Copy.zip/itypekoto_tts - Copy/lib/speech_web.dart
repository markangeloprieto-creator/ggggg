import 'dart:html';
import 'dart:js_util' as js_util;
import 'package:js/js.dart';

// change typedef to include index
typedef ResultCallback = void Function(String? text, bool isFinal, int resultIndex);
typedef VoidCallback = void Function();

class WebSpeechApi {
  dynamic recognition;
  bool keepListening = false;

  WebSpeechApi() {
    var speechRecognition =
        js_util.getProperty(window, 'SpeechRecognition') ??
            js_util.getProperty(window, 'webkitSpeechRecognition');

    if (speechRecognition != null) {
      recognition = js_util.callConstructor(speechRecognition, []);
    }
  }

  static bool get isSupported {
    var speechRecognition =
        js_util.getProperty(window, 'SpeechRecognition') ??
            js_util.getProperty(window, 'webkitSpeechRecognition');
    return speechRecognition != null;
  }

  void initialize({
    required ResultCallback onResult,
    VoidCallback? onEnd,
    Function(String)? onError,
    bool debug = false,
  }) {
    if (recognition == null) return;

    js_util.setProperty(recognition, 'lang', 'en-US');
    js_util.setProperty(recognition, 'continuous', true);
    js_util.setProperty(recognition, 'interimResults', true);

    js_util.setProperty(
      recognition,
      'onresult',
      allowInterop((event) {
        try {
          final results = js_util.getProperty(event, 'results');
          if (results == null) return;

          final resultIndexDynamic = js_util.getProperty(event, 'resultIndex') ?? 0;
          final int startIndex = (resultIndexDynamic is num) ? resultIndexDynamic.toInt() : 0;

          // when reporting each result, pass the index
          for (int i = startIndex; i < results.length; i++) {
            final result = js_util.getProperty(results, i);
            final isFinalDynamic = js_util.getProperty(result, 'isFinal');
            final bool isFinal = (isFinalDynamic == null) ? false : (isFinalDynamic as bool);

            final alternatives = js_util.getProperty(result, 0);
            final transcript = (js_util.getProperty(alternatives, 'transcript') ?? "").toString().trim();

            if (transcript.isNotEmpty) {
              onResult(transcript, isFinal, i); // <-- three args
            }
          }
        } catch (e) {
          if (onError != null) onError("Result parse error: $e");
        }
      }),
    );

    js_util.setProperty(
      recognition,
      'onend',
      allowInterop((event) {
        // debug: recognition ended. keepListening=$keepListening
        if (keepListening) {
          try {
            js_util.callMethod(recognition, 'start', []);
          } catch (_) {}
        } else {
          onEnd?.call();
        }
      }),
    );

    js_util.setProperty(
      recognition,
      'onerror',
      allowInterop((event) {
        final err = js_util.getProperty(event, 'error');
        // debug: recognition error: $err
        if (onError != null) onError(err?.toString() ?? "Unknown error");
      }),
    );
  }

  // ensure start signature uses ResultCallback
  void start(ResultCallback onResult, {Function(String)? onError, VoidCallback? onEnd, bool debug = false}) {
    if (recognition == null) {
      onError?.call("Speech recognition not supported in this browser.");
      return;
    }

    keepListening = true;
    initialize(onResult: onResult, onError: onError, onEnd: onEnd, debug: debug);

    try {
      if (debug) print("DEBUG: starting recognition...");
      js_util.callMethod(recognition, 'start', []);
    } catch (e) {
      if (onError != null) onError("Start error: $e");
    }
  }

  void stop() {
    keepListening = false;
    if (recognition != null) {
      try {
        js_util.callMethod(recognition, 'stop', []);
      } catch (_) {}
    }
  }
}
