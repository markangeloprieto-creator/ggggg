package com.example.itypekoto_tts

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
